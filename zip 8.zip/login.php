<?php
echo $_POST['mail']."<br>";
echo $_POST['pass'];
?>